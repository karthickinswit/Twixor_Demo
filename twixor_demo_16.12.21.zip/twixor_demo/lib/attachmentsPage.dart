import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AttachmentsPage extends StatefulWidget {

  const AttachmentsPage({Key? key}) : super(key: key);
  @override
  _AttachmentsPage createState() => _AttachmentsPage();

}

class _AttachmentsPage extends State<AttachmentsPage> with SingleTickerProviderStateMixin{
  late TabController _tabController;
  @override
  void initState() {
    this.initState();
    _tabController = TabController(
        vsync: this, length:2
    );
  }


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: Text("Attachments"),

        ),
        body: Row(
          // Padding:,


          children:[
            tabbar(),

          ],



        ),

      ),
        );

  }

  Widget tabbar() {
    //return MaterialApp(
    // return MaterialApp(
    //   home: DefaultTabController(
    //     length: 2,
    //     child: Scaffold(
    //       bottomNavigationBar: ,
    //     ),
    //   ),
    // );

   return  DefaultTabController(
        length: 2,

        child:
        new TabBar(
          controller: _tabController,
          tabs: <Widget>[
            Tab(

              child: Text(
                'Private',
                style: TextStyle(fontSize: 10),
              ),
            ),
            Tab(

              child: Text(
                'Public',
                style: TextStyle(fontSize: 10),
              ),
            ),
          ],
          labelColor: Colors.blue,
          unselectedLabelColor: Colors.grey,
        )
     //    Row(
     //      children:[
     //
     //      Container(
     //        alignment: AlignmentDirectional.topStart,
     //        child:  PreferredSize(
     //          child: Material(
     //            child: Container(
     //              height: 40,
     //              child: new TabBar(
     //                tabs: <Widget>[
     //                  Tab(
     //
     //                    child: Text(
     //                      'Private',
     //                      style: TextStyle(fontSize: 10),
     //                    ),
     //                  ),
     //                  Tab(
     //
     //                    child: Text(
     //                      'Public',
     //                      style: TextStyle(fontSize: 10),
     //                    ),
     //                  ),
     //                ],
     //                labelColor: Colors.blue,
     //                unselectedLabelColor: Colors.grey,
     //              ),
     //            ),
     //
     //          ),
     //
     //          preferredSize: Size.fromHeight(75.0),
     //        ),
     //
     //
     //
     //      ),
     //      Expanded(
     //        child: TabBarView(
     //          children: [
     //            // first tab bar view widget
     //            Container(
     //              color: Colors.red,
     //              child: Center(
     //                child: Text(
     //                  'Bike',
     //                ),
     //              ),
     //            ),
     //
     //            // second tab bar viiew widget
     //            Container(
     //              color: Colors.pink,
     //              child: Center(
     //                child: Text(
     //                  'Car',
     //                ),
     //              ),
     //            ),
     //          ],
     //        ),
     //      ),
     // ]
     //    ),


      );

  }
}
