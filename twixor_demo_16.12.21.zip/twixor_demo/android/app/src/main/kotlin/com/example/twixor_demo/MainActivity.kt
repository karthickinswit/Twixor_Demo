package com.example.twixor_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
